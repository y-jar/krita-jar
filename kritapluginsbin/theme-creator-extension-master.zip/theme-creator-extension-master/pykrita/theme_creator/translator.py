import gettext
import os.path

# Name of the .mo file; same as the plugin
filename = "theme_creator"
# Location of the folder which contains /[lang]/LC_MESSAGES/filename.mo;
# /[plugin]/translations/
path = os.path.join(os.path.dirname(__file__), "translations")

translator = gettext.translation(filename, path, fallback=True)
# The function used to translate strings;
# _(), as per convention
_ = translator.gettext
# The function to translate strings with context;
# _c. Requires passing to xgettext --keyword=_c:1c,2
_c = translator.pgettext
