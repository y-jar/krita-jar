### Translating the plugin:

[Python's recommended way of doing translations](https://docs.python.org/3/library/gettext.html) is to use [gettext](https://www.gnu.org/software/gettext/).
There are [Python implementations of xgettext and msgfmt](https://github.com/python/cpython/tree/main/Tools/i18n) which can be used as an alternative to installing the command line utilities.

Translating consists of the following steps:
1. Generate the `.po` file from the source code using `xgettext`. This is the text file the translator will edit.
```
cd /pathto/pykrita/theme_creator/
xgettext ./theme_creator.py -o /somewhere/theme_creator.po --keyword=_c:1c,2
```
Passing a relative script path (`./theme_creator.py`) means the filename comment in the `.po` file will also match this shorter form.
`--keyword=_c:1c,2` lets gettext know about the script's custom _c() function for strings with context.
1a. To update an existing `.po` file without overwriting it, add `--join-existing`.
```
xgettext ./theme_creator.py -o /somewhere/theme_creator.po --keyword=_c:1c,2 --join-existing
```

2. Add translations to the `.po` file using a text editor or specialized localization tool.
```
msgid "Name:"
msgstr "Nombre:"
```
3. Generate the `.mo` file from the `.po` file using `msgfmt`. This is the binary file that the code will read the translations from.
The `.mo` file must be located at "/theme_creator/translations/[language code
]/LC_MESSAGES/theme_creator.mo" for the code to find it. You may have to create those subfolders first.
`msgfmt /somewhere/theme_creator.po -o /theme_creator/translations/es/LC_MESSAGES/theme_creator.mo`

### Translating the name, comment, and manual shown in Python Plugins Manager:
This requires editing the plugin's .desktop file found in the pykrita folder.
Put the proper language code in [brackets] after the key name:
```
Name[es]=(Name but en Español)
Comment[es]=(Comment but en Español)
X-Krita-Manual[es]=Manual_es.html
```
And then create a manual with the given filename in the plugin's folder.
